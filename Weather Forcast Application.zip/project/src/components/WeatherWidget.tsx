import React from 'react';
import { Sunrise, Sunset, Wind, Droplets, Eye, Gauge } from 'lucide-react';

interface WeatherWidgetProps {
  icon: React.ElementType;
  title: string;
  value: string | number;
  unit: string;
  color: string;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({
  icon: Icon,
  title,
  value,
  unit,
  color,
}) => {
  return (
    <div className="bg-gray-800/50 rounded-xl p-4 sm:p-6 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-4">
        <span className="text-gray-400 text-sm">{title}</span>
        <Icon className={`${color}`} size={24} />
      </div>
      <div className="flex items-end gap-2">
        <span className="text-xl sm:text-2xl font-bold text-white">{value}</span>
        <span className="text-gray-400 mb-1">{unit}</span>
      </div>
    </div>
  );
};

export const SunriseSunsetWidget: React.FC<{
  sunrise: string;
  sunset: string;
}> = ({ sunrise, sunset }) => {
  return (
    <div className="bg-gray-800/50 rounded-xl p-4 sm:p-6 backdrop-blur-sm">
      <h3 className="text-white font-semibold mb-4">Sunrise & Sunset</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="flex items-center gap-3">
          <Sunrise className="text-yellow-400" size={24} />
          <div>
            <p className="text-gray-400 text-sm">Sunrise</p>
            <p className="text-white font-semibold">{sunrise}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Sunset className="text-orange-400" size={24} />
          <div>
            <p className="text-gray-400 text-sm">Sunset</p>
            <p className="text-white font-semibold">{sunset}</p>
          </div>
        </div>
      </div>
    </div>
  );
};