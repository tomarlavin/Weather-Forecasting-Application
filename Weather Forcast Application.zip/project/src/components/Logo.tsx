import React from 'react';
import { Cloud, Sun } from 'lucide-react';

export const Logo: React.FC = () => {
  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        <Sun className="text-yellow-400" size={28} />
        <Cloud className="text-blue-400 absolute -bottom-1 -right-1" size={20} />
      </div>
      <span className="text-xl font-bold text-white">Skycast</span>
    </div>
  );
};