import React from 'react';
import { Clock, X } from 'lucide-react';
import { useWeatherStore } from '../store/weatherStore';

export const RecentSearches: React.FC<{ onSelect: (city: string) => void }> = ({ onSelect }) => {
  const { searchHistory, clearHistory } = useWeatherStore();

  if (searchHistory.length === 0) return null;

  return (
    <div className="mt-4 bg-gray-800/50 rounded-xl p-4 backdrop-blur-sm">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Clock className="text-blue-400" size={18} />
          <h3 className="text-sm font-medium text-white">Recent Searches</h3>
        </div>
        <button
          onClick={clearHistory}
          className="text-gray-400 hover:text-white transition-colors"
        >
          <X size={18} />
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        {searchHistory.map((city) => (
          <button
            key={city}
            onClick={() => onSelect(city)}
            className="px-3 py-1 bg-gray-700/50 hover:bg-gray-600/50 rounded-full text-sm text-white transition-colors"
          >
            {city}
          </button>
        ))}
      </div>
    </div>
  );
};