import React from 'react';
import { AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface WeatherAlertProps {
  condition: string;
  temperature: number;
  humidity: number;
  windSpeed: number;
}

export const checkWeatherAlert = ({ condition, temperature, humidity, windSpeed }: WeatherAlertProps) => {
  const alerts = [];

  // Severe weather conditions
  if (condition.toLowerCase().includes('thunderstorm')) {
    alerts.push('⚡ Thunderstorm warning! Take necessary precautions.');
  }
  if (condition.toLowerCase().includes('rain') && windSpeed > 10) {
    alerts.push('🌧️ Heavy rain and strong winds expected.');
  }
  if (condition.toLowerCase().includes('snow')) {
    alerts.push('❄️ Snowfall expected. Drive carefully.');
  }

  // Temperature alerts
  if (temperature > 35) {
    alerts.push('🌡️ Extreme heat alert! Stay hydrated and avoid direct sun exposure.');
  }
  if (temperature < 0) {
    alerts.push('🥶 Freezing temperatures! Bundle up and watch for ice.');
  }

  // Wind alerts
  if (windSpeed > 15) {
    alerts.push('💨 Strong winds alert! Secure loose objects outdoors.');
  }

  // Humidity alerts
  if (humidity > 85) {
    alerts.push('💧 High humidity levels. Stay cool and hydrated.');
  }
  if (humidity < 30) {
    alerts.push('🏜️ Very dry conditions. Stay hydrated.');
  }

  // Show alerts if any
  alerts.forEach((alert) => {
    toast(alert, {
      duration: 6000,
      icon: <AlertTriangle className="text-yellow-500" />,
    });
  });

  return alerts.length > 0;
};