import React, { useState, useContext } from 'react';
import { Search, MapPin } from 'lucide-react';
import { LocationContext } from '../context/LocationContext';
import { SettingsContext } from '../context/SettingsContext';
import { BackgroundContext } from '../context/BackgroundContext';
import { fetchWeather, fetchForecast, fetchAirQuality } from '../utils/api';
import { checkWeatherAlert } from './WeatherAlert';
import { Toaster } from 'sonner';
import { useWeatherStore } from '../store/weatherStore';

interface SearchBarProps {
  onSearch: (city: string) => void;
  onLocationClick?: () => void;
  showLocationButton?: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({ 
  onSearch, 
  onLocationClick,
  showLocationButton = true 
}) => {
  const [query, setQuery] = useState('');
  const { setCurrentWeather, setForecast, setAirQuality } = useContext(LocationContext);
  const { units, notifications } = useContext(SettingsContext);
  const { updateBackgroundForWeather } = useContext(BackgroundContext);
  const { addToSearchHistory } = useWeatherStore();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      try {
        const weatherData = await fetchWeather(query.trim(), units);
        const forecastData = await fetchForecast(query.trim(), units);
        const { lat, lon } = weatherData.coord;
        const airQualityData = await fetchAirQuality(lat, lon);

        setCurrentWeather(weatherData);
        setForecast(forecastData);
        setAirQuality(airQualityData);
        addToSearchHistory(query.trim());
        
        await updateBackgroundForWeather(query.trim(), weatherData.weather[0].main);

        if (notifications) {
          checkWeatherAlert({
            condition: weatherData.weather[0].main,
            temperature: weatherData.main.temp,
            humidity: weatherData.main.humidity,
            windSpeed: weatherData.wind.speed
          });
        }

        onSearch(query.trim());
        setQuery('');
      } catch (err) {
        toast.error('City not found. Please try again.');
      }
    }
  };

  return (
    <>
      <form onSubmit={handleSearch} className="w-full max-w-3xl mx-auto">
        <div className="relative flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search city..."
              className="w-full px-4 py-3 pl-12 bg-gray-800/50 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              className="flex-1 sm:flex-none px-6 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
            >
              Search
            </button>
            {showLocationButton && (
              <button
                type="button"
                onClick={onLocationClick}
                className="px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors"
              >
                <MapPin size={20} />
              </button>
            )}
          </div>
        </div>
      </form>
      <Toaster position="top-right" />
    </>
  );
};