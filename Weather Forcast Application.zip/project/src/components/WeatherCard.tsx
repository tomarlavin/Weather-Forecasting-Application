import React from 'react';
import { Sun, Cloud, CloudRain, Thermometer } from 'lucide-react';
import type { WeatherData } from '../types/weather';

interface WeatherCardProps {
  weather: WeatherData;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({ weather }) => {
  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'clear':
        return <Sun className="text-yellow-400" size={48} />;
      case 'clouds':
        return <Cloud className="text-gray-400" size={48} />;
      case 'rain':
        return <CloudRain className="text-blue-400" size={48} />;
      default:
        return <Thermometer className="text-red-400" size={48} />;
    }
  };

  return (
    <div className="bg-gray-800/50 rounded-xl p-4 sm:p-6 backdrop-blur-sm">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            {Math.round(weather.main.temp)}°C
          </h2>
          <p className="text-gray-400 mt-1">{weather.weather[0].main}</p>
          <p className="text-sm text-gray-500 mt-2">{weather.name}</p>
        </div>
        <div className="flex justify-center">
          {getWeatherIcon(weather.weather[0].main)}
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
        <div className="bg-gray-700/30 p-3 rounded-lg">
          <p className="text-gray-400 text-sm">Feels Like</p>
          <p className="text-white font-semibold">
            {Math.round(weather.main.feels_like)}°C
          </p>
        </div>
        <div className="bg-gray-700/30 p-3 rounded-lg">
          <p className="text-gray-400 text-sm">Humidity</p>
          <p className="text-white font-semibold">{weather.main.humidity}%</p>
        </div>
      </div>
    </div>
  );
};