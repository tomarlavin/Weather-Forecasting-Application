interface Recommendation {
  name: string;
  type: string;
  description: string;
  icon: string;
}

export const getLocationRecommendations = (
  weather: string,
  temp: number,
  city: string,
  country: string
): Recommendation[] => {
  const recommendations: Recommendation[] = [];
  const weatherLower = weather.toLowerCase();
  
  // Weather-based activities
  if (weatherLower.includes('clear') && temp > 20 && temp < 30) {
    recommendations.push({
      name: "Outdoor Activities",
      type: "Recreation",
      description: `Perfect weather for exploring ${city}'s parks and outdoor attractions`,
      icon: "Mountain"
    });
  }

  if (weatherLower.includes('rain')) {
    recommendations.push({
      name: "Indoor Culture",
      type: "Entertainment",
      description: `Visit ${city}'s museums, galleries, or catch a show at local theaters`,
      icon: "Museum"
    });
  }

  // Temperature-based activities
  if (temp > 25) {
    recommendations.push({
      name: "Water Activities",
      type: "Recreation",
      description: `Cool off at local pools, water parks, or nearby beaches in ${city}`,
      icon: "Beach"
    });
  }

  if (temp < 15) {
    recommendations.push({
      name: "Cozy Spots",
      type: "Entertainment",
      description: `Enjoy ${city}'s cafes, bookstores, and indoor entertainment venues`,
      icon: "Coffee"
    });
  }

  // Location-specific recommendations
  if (country === 'FR') {
    recommendations.push({
      name: "French Culture",
      type: "Tourism",
      description: "Experience local cafes, patisseries, and French architecture",
      icon: "Coffee"
    });
  }

  if (country === 'IT') {
    recommendations.push({
      name: "Italian Experience",
      type: "Tourism",
      description: "Visit historical sites, enjoy authentic Italian cuisine",
      icon: "Landmark"
    });
  }

  if (country === 'JP') {
    recommendations.push({
      name: "Japanese Culture",
      type: "Tourism",
      description: "Explore temples, gardens, and traditional Japanese spots",
      icon: "Temple"
    });
  }

  // Add default recommendations if none are generated
  if (recommendations.length === 0) {
    recommendations.push({
      name: "Local Exploration",
      type: "Tourism",
      description: `Discover ${city}'s unique attractions and local culture`,
      icon: "Compass"
    });
  }

  return recommendations;
};