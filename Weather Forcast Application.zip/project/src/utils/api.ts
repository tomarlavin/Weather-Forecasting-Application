import { SettingsContext } from '../context/SettingsContext';
import { useContext } from 'react';

const API_KEY = "08d1d552fcc23843276535db21cdf95f";
const UNSPLASH_ACCESS_KEY = "zCg9Z1Z6qBB-cjWEJh5zDLXpy1FW6LdY5f9MvFgbEsE";
const BASE_URL = "https://api.openweathermap.org/data/2.5";

export const fetchWeather = async (city: string, units: string = 'metric') => {
  const response = await fetch(
    `${BASE_URL}/weather?q=${city}&units=${units}&appid=${API_KEY}`
  );
  if (!response.ok) throw new Error('City not found');
  return response.json();
};

export const fetchForecast = async (city: string, units: string = 'metric') => {
  const response = await fetch(
    `${BASE_URL}/forecast?q=${city}&units=${units}&appid=${API_KEY}&cnt=56`
  );
  if (!response.ok) throw new Error('City not found');
  return response.json();
};

export const fetchWeatherByCoords = async (lat: number, lon: number, units: string = 'metric') => {
  const response = await fetch(
    `${BASE_URL}/weather?lat=${lat}&lon=${lon}&units=${units}&appid=${API_KEY}`
  );
  if (!response.ok) throw new Error('Location not found');
  return response.json();
};

export const fetchForecastByCoords = async (lat: number, lon: number, units: string = 'metric') => {
  const response = await fetch(
    `${BASE_URL}/forecast?lat=${lat}&lon=${lon}&units=${units}&appid=${API_KEY}&cnt=56`
  );
  if (!response.ok) throw new Error('Location not found');
  return response.json();
};

export const fetchAirQuality = async (lat: number, lon: number) => {
  const response = await fetch(
    `${BASE_URL}/air_pollution?lat=${lat}&lon=${lon}&appid=${API_KEY}`
  );
  if (!response.ok) throw new Error('Air quality data not available');
  return response.json();
};

export const fetchCityImage = async (query: string) => {
  try {
    const encodedQuery = encodeURIComponent(query);
    const response = await fetch(
      `https://api.unsplash.com/search/photos?query=${encodedQuery}&client_id=${UNSPLASH_ACCESS_KEY}&orientation=landscape&per_page=1`
    );
    if (!response.ok) {
      // Fallback to Pexels API if Unsplash fails
      const pexelsResponse = await fetch(
        `https://api.pexels.com/v1/search?query=${encodedQuery}&per_page=1&orientation=landscape`,
        {
          headers: {
            Authorization: 'zCg9Z1Z6qBB-cjWEJh5zDLXpy1FW6LdY5f9MvFgbEsE'
          }
        }
      );
      if (!pexelsResponse.ok) throw new Error('Failed to fetch city image');
      const pexelsData = await pexelsResponse.json();
      return pexelsData.photos[0]?.src.large2x;
    }
    const data = await response.json();
    return data.results[0]?.urls.regular;
  } catch (err) {
    console.error('Error fetching city image:', err);
    return 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg';
  }
};

export const getTemperatureUnit = (unit: string) => {
  switch (unit) {
    case 'imperial':
      return '°F';
    case 'standard':
      return 'K';
    default:
      return '°C';
  }
};

export const convertTemperature = (temp: number, fromUnit: string, toUnit: string): number => {
  if (fromUnit === toUnit) return temp;

  // Convert to Kelvin first
  let kelvin = temp;
  if (fromUnit === 'metric') {
    kelvin = temp + 273.15;
  } else if (fromUnit === 'imperial') {
    kelvin = (temp - 32) * 5/9 + 273.15;
  }

  // Convert from Kelvin to target unit
  if (toUnit === 'metric') {
    return kelvin - 273.15;
  } else if (toUnit === 'imperial') {
    return (kelvin - 273.15) * 9/5 + 32;
  }
  return kelvin;
};