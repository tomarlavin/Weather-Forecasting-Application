import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { WeatherData, ForecastData } from '../types/weather';

interface WeatherStore {
  currentWeather: WeatherData | null;
  forecast: ForecastData | null;
  airQuality: any | null;
  searchHistory: string[];
  isLoading: boolean;
  error: string | null;
  setCurrentWeather: (weather: WeatherData | null) => void;
  setForecast: (forecast: ForecastData | null) => void;
  setAirQuality: (airQuality: any | null) => void;
  addToSearchHistory: (city: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  clearHistory: () => void;
}

export const useWeatherStore = create<WeatherStore>()(
  persist(
    (set) => ({
      currentWeather: null,
      forecast: null,
      airQuality: null,
      searchHistory: [],
      isLoading: false,
      error: null,
      setCurrentWeather: (weather) => set({ currentWeather: weather }),
      setForecast: (forecast) => set({ forecast }),
      setAirQuality: (airQuality) => set({ airQuality }),
      addToSearchHistory: (city) =>
        set((state) => ({
          searchHistory: [
            city,
            ...state.searchHistory.filter((c) => c !== city)
          ].slice(0, 5)
        })),
      setLoading: (loading) => set({ isLoading: loading }),
      setError: (error) => set({ error }),
      clearHistory: () => set({ searchHistory: [] })
    }),
    {
      name: 'weather-storage'
    }
  )
);