import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface SettingsStore {
  units: 'metric' | 'imperial' | 'standard';
  theme: 'light' | 'dark' | 'system';
  notifications: boolean;
  sound: boolean;
  language: string;
  updateInterval: number;
  alertVolume: number;
  setUnits: (units: 'metric' | 'imperial' | 'standard') => void;
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  setNotifications: (enabled: boolean) => void;
  setSound: (enabled: boolean) => void;
  setLanguage: (lang: string) => void;
  setUpdateInterval: (interval: number) => void;
  setAlertVolume: (volume: number) => void;
}

export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      units: 'metric',
      theme: 'system',
      notifications: true,
      sound: true,
      language: 'en',
      updateInterval: 30,
      alertVolume: 80,
      setUnits: (units) => set({ units }),
      setTheme: (theme) => {
        set({ theme });
        if (theme === 'system') {
          const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
          document.documentElement.classList.toggle('dark', isDark);
        } else {
          document.documentElement.classList.toggle('dark', theme === 'dark');
        }
      },
      setNotifications: (notifications) => set({ notifications }),
      setSound: (sound) => set({ sound }),
      setLanguage: (language) => set({ language }),
      setUpdateInterval: (updateInterval) => set({ updateInterval }),
      setAlertVolume: (alertVolume) => set({ alertVolume })
    }),
    {
      name: 'settings-storage'
    }
  )
);