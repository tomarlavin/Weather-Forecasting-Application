import { useState, useEffect, useContext } from 'react';
import { useSettingsStore } from '../store/settingsStore';
import { useWeatherStore } from '../store/weatherStore';
import { BackgroundContext } from '../context/BackgroundContext';
import { fetchWeatherByCoords, fetchForecastByCoords, fetchAirQuality, fetchCityImage } from '../utils/api';

interface GeolocationState {
  loading: boolean;
  error: string | null;
  coords: {
    latitude: number;
    longitude: number;
  } | null;
}

export const useGeolocation = () => {
  const [state, setState] = useState<GeolocationState>({
    loading: true,
    error: null,
    coords: null
  });

  const { units } = useSettingsStore();
  const { setCurrentWeather, setForecast, setAirQuality, setLoading, setError } = useWeatherStore();
  const { updateBackgroundForWeather } = useContext(BackgroundContext);

  const watchLocation = () => {
    if (!navigator.geolocation) {
      setState({
        loading: false,
        error: 'Geolocation is not supported by your browser',
        coords: null
      });
      return null;
    }

    return navigator.geolocation.watchPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          
          const [weather, forecast, airQuality] = await Promise.all([
            fetchWeatherByCoords(latitude, longitude, units),
            fetchForecastByCoords(latitude, longitude, units),
            fetchAirQuality(latitude, longitude)
          ]);

          setCurrentWeather(weather);
          setForecast(forecast);
          setAirQuality(airQuality);
          updateBackgroundForWeather(weather.name, weather.weather[0].main);
          setError(null);

          setState({
            loading: false,
            error: null,
            coords: { latitude, longitude }
          });
        } catch (err) {
          setState({
            loading: false,
            error: 'Failed to fetch weather data',
            coords: null
          });
          setError('Failed to fetch weather data');
        } finally {
          setLoading(false);
        }
      },
      (error) => {
        let errorMessage = 'Failed to get location';
        if (error.code === 1) {
          errorMessage = 'Location access denied. Please enable location services.';
        } else if (error.code === 2) {
          errorMessage = 'Location unavailable. Please try again.';
        } else if (error.code === 3) {
          errorMessage = 'Location request timed out. Please try again.';
        }
        setState({
          loading: false,
          error: errorMessage,
          coords: null
        });
        setError(errorMessage);
        setLoading(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  useEffect(() => {
    const watchId = watchLocation();
    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [units]);

  const getLocation = () => {
    setState(prev => ({ ...prev, loading: true }));
    setLoading(true);
    const watchId = watchLocation();
    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  };

  return { ...state, getLocation };
};