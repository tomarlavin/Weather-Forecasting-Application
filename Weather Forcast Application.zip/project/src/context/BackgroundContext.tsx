import React, { createContext, useState, useEffect } from 'react';
import { fetchCityImage } from '../utils/api';

interface BackgroundContextType {
  backgroundImage: string;
  setBackgroundImage: (url: string) => void;
  updateBackgroundForWeather: (city: string, weather: string) => void;
}

export const BackgroundContext = createContext<BackgroundContextType>({
  backgroundImage: 'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg',
  setBackgroundImage: () => {},
  updateBackgroundForWeather: () => {},
});

export const BackgroundProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [backgroundImage, setBackgroundImage] = useState('https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg');

  const updateBackgroundForWeather = async (city: string, weather: string) => {
    try {
      const query = `${city} ${weather} weather ${weather.toLowerCase().includes('night') ? 'night' : 'day'}`;
      const imageUrl = await fetchCityImage(query);
      if (imageUrl) {
        setBackgroundImage(imageUrl);
      }
    } catch (error) {
      console.error('Failed to update background:', error);
    }
  };

  return (
    <BackgroundContext.Provider value={{ backgroundImage, setBackgroundImage, updateBackgroundForWeather }}>
      {children}
    </BackgroundContext.Provider>
  );
};