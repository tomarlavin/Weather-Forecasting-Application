import React, { createContext, useState, useEffect } from 'react';

interface SettingsContextType {
  units: 'metric' | 'imperial' | 'standard';
  theme: 'light' | 'dark' | 'system';
  notifications: boolean;
  sound: boolean;
  language: string;
  updateInterval: number;
  alertVolume: number;
  setUnits: (units: 'metric' | 'imperial' | 'standard') => void;
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  setNotifications: (enabled: boolean) => void;
  setSound: (enabled: boolean) => void;
  setLanguage: (lang: string) => void;
  setUpdateInterval: (interval: number) => void;
  setAlertVolume: (volume: number) => void;
}

export const SettingsContext = createContext<SettingsContextType>({
  units: 'metric',
  theme: 'dark',
  notifications: true,
  sound: true,
  language: 'en',
  updateInterval: 30,
  alertVolume: 80,
  setUnits: () => {},
  setTheme: () => {},
  setNotifications: () => {},
  setSound: () => {},
  setLanguage: () => {},
  setUpdateInterval: () => {},
  setAlertVolume: () => {},
});

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [units, setUnits] = useState<'metric' | 'imperial' | 'standard'>('metric');
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('dark');
  const [notifications, setNotifications] = useState(true);
  const [sound, setSound] = useState(true);
  const [language, setLanguage] = useState('en');
  const [updateInterval, setUpdateInterval] = useState(30);
  const [alertVolume, setAlertVolume] = useState(80);

  useEffect(() => {
    // Apply theme
    if (theme === 'system') {
      const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      document.documentElement.classList.toggle('dark', isDark);
    } else {
      document.documentElement.classList.toggle('dark', theme === 'dark');
    }
  }, [theme]);

  useEffect(() => {
    // Save settings to localStorage
    const settings = {
      units,
      theme,
      notifications,
      sound,
      language,
      updateInterval,
      alertVolume,
    };
    localStorage.setItem('weather-app-settings', JSON.stringify(settings));
  }, [units, theme, notifications, sound, language, updateInterval, alertVolume]);

  return (
    <SettingsContext.Provider
      value={{
        units,
        theme,
        notifications,
        sound,
        language,
        updateInterval,
        alertVolume,
        setUnits,
        setTheme,
        setNotifications,
        setSound,
        setLanguage,
        setUpdateInterval,
        setAlertVolume,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};