import React, { createContext, useState } from 'react';
import type { WeatherData, ForecastData } from '../types/weather';

interface LocationContextType {
  currentWeather: WeatherData | null;
  forecast: ForecastData | null;
  airQuality: any | null;
  setCurrentWeather: (weather: WeatherData | null) => void;
  setForecast: (forecast: ForecastData | null) => void;
  setAirQuality: (airQuality: any | null) => void;
}

export const LocationContext = createContext<LocationContextType>({
  currentWeather: null,
  forecast: null,
  airQuality: null,
  setCurrentWeather: () => {},
  setForecast: () => {},
  setAirQuality: () => {},
});

export const LocationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentWeather, setCurrentWeather] = useState<WeatherData | null>(null);
  const [forecast, setForecast] = useState<ForecastData | null>(null);
  const [airQuality, setAirQuality] = useState<any | null>(null);

  return (
    <LocationContext.Provider 
      value={{ 
        currentWeather, 
        setCurrentWeather, 
        forecast, 
        setForecast,
        airQuality,
        setAirQuality
      }}
    >
      {children}
    </LocationContext.Provider>
  );
};