import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navigation } from './components/Navigation';
import { Home } from './pages/Home';
import { Forecast } from './pages/Forecast';
import { AirQuality } from './pages/AirQuality';
import { Maps } from './pages/Maps';
import { Settings } from './pages/Settings';
import { BackgroundContext, BackgroundProvider } from './context/BackgroundContext';
import { LocationProvider } from './context/LocationContext';
import { SettingsProvider } from './context/SettingsContext';

function AppContent() {
  const { backgroundImage } = useContext(BackgroundContext);

  return (
    <Router>
      <div 
        className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 transition-all duration-500"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.7)), url('${backgroundImage}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed'
        }}
      >
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/forecast" element={<Forecast />} />
            <Route path="/air-quality" element={<AirQuality />} />
            <Route path="/maps" element={<Maps />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function App() {
  return (
    <SettingsProvider>
      <BackgroundProvider>
        <LocationProvider>
          <AppContent />
        </LocationProvider>
      </BackgroundProvider>
    </SettingsProvider>
  );
}

export default App;