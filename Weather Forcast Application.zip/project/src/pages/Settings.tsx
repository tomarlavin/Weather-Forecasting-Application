import React, { useContext } from 'react';
import { Sun, Moon, Thermometer, Bell, Volume2, Languages, Clock } from 'lucide-react';
import * as Switch from '@radix-ui/react-switch';
import * as Slider from '@radix-ui/react-slider';
import { SettingsContext } from '../context/SettingsContext';

export const Settings: React.FC = () => {
  const {
    units,
    theme,
    notifications,
    sound,
    language,
    updateInterval,
    alertVolume,
    setUnits,
    setTheme,
    setNotifications,
    setSound,
    setLanguage,
    setUpdateInterval,
    setAlertVolume,
  } = useContext(SettingsContext);

  return (
    <div className="max-w-4xl mx-auto px-4">
      <h1 className="text-3xl font-bold text-white text-center mb-8">
        Settings
      </h1>

      <div className="space-y-6">
        <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Thermometer className="text-blue-400" size={24} />
              <div>
                <h3 className="text-lg font-medium text-white">Temperature Units</h3>
                <p className="text-sm text-gray-400">Choose your preferred temperature unit</p>
              </div>
            </div>
            <select
              value={units}
              onChange={(e) => setUnits(e.target.value as 'metric' | 'imperial' | 'standard')}
              className="bg-gray-700 text-white rounded-lg px-4 py-2"
            >
              <option value="metric">Celsius (°C)</option>
              <option value="imperial">Fahrenheit (°F)</option>
              <option value="standard">Kelvin (K)</option>
            </select>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {theme === 'dark' ? (
                <Moon className="text-blue-400" size={24} />
              ) : (
                <Sun className="text-yellow-400" size={24} />
              )}
              <div>
                <h3 className="text-lg font-medium text-white">Theme</h3>
                <p className="text-sm text-gray-400">Choose your preferred theme</p>
              </div>
            </div>
            <select
              value={theme}
              onChange={(e) => setTheme(e.target.value as 'light' | 'dark' | 'system')}
              className="bg-gray-700 text-white rounded-lg px-4 py-2"
            >
              <option value="light">Light</option>
              <option value="dark">Dark</option>
              <option value="system">System Default</option>
            </select>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Bell className="text-blue-400" size={24} />
              <div>
                <h3 className="text-lg font-medium text-white">Weather Alerts</h3>
                <p className="text-sm text-gray-400">Get notified about severe weather conditions</p>
              </div>
            </div>
            <Switch.Root
              checked={notifications}
              onCheckedChange={setNotifications}
              className="w-11 h-6 bg-gray-700 rounded-full relative data-[state=checked]:bg-blue-600 outline-none cursor-pointer"
            >
              <Switch.Thumb className="block w-5 h-5 bg-white rounded-full transition-transform duration-100 translate-x-0.5 will-change-transform data-[state=checked]:translate-x-[22px]" />
            </Switch.Root>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Volume2 className="text-blue-400" size={24} />
              <div>
                <h3 className="text-lg font-medium text-white">Alert Volume</h3>
                <p className="text-sm text-gray-400">Adjust the volume of weather alerts</p>
              </div>
            </div>
            <div className="w-32">
              <Slider.Root
                className="relative flex items-center select-none touch-none w-full h-5"
                value={[alertVolume]}
                onValueChange={(value) => setAlertVolume(value[0])}
                max={100}
                step={1}
              >
                <Slider.Track className="bg-gray-700 relative grow rounded-full h-2">
                  <Slider.Range className="absolute bg-blue-600 rounded-full h-full" />
                </Slider.Track>
                <Slider.Thumb
                  className="block w-5 h-5 bg-white rounded-full hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  aria-label="Volume"
                />
              </Slider.Root>
            </div>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Languages className="text-blue-400" size={24} />
              <div>
                <h3 className="text-lg font-medium text-white">Language</h3>
                <p className="text-sm text-gray-400">Choose your preferred language</p>
              </div>
            </div>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-gray-700 text-white rounded-lg px-4 py-2"
            >
              <option value="en">English</option>
              <option value="es">Español</option>
              <option value="fr">Français</option>
              <option value="de">Deutsch</option>
              <option value="hi">Hindi</option>
            </select>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Clock className="text-blue-400" size={24} />
              <div>
                <h3 className="text-lg font-medium text-white">Update Interval</h3>
                <p className="text-sm text-gray-400">How often to refresh weather data</p>
              </div>
            </div>
            <select
              value={updateInterval}
              onChange={(e) => setUpdateInterval(Number(e.target.value))}
              className="bg-gray-700 text-white rounded-lg px-4 py-2"
            >
              <option value="15">15 minutes</option>
              <option value="30">30 minutes</option>
              <option value="60">1 hour</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};