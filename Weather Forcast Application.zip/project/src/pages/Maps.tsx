import React, { useEffect, useRef, useState, useContext } from 'react';
import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import Feature from 'ol/Feature';
import Point from 'ol/geom/Point';
import OSM from 'ol/source/OSM';
import { fromLonLat } from 'ol/proj';
import { Style, Icon } from 'ol/style';
import { SearchBar } from '../components/SearchBar';
import { Compass, Hotel, Coffee, Camera, Umbrella, Mountain, Bean as Beach, Mouse as Museum } from 'lucide-react';
import { BackgroundContext } from '../context/BackgroundContext';
import { LocationContext } from '../context/LocationContext';
import { SettingsContext } from '../context/SettingsContext';
import { fetchCityImage } from '../utils/api';
import { getLocationRecommendations } from '../utils/recommendations';
import 'ol/ol.css';

interface PlaceInfo {
  name: string;
  type: string;
  description: string;
  icon: React.ElementType;
}

const iconMap: { [key: string]: React.ElementType } = {
  Mountain,
  Beach,
  Museum,
  Coffee,
  Hotel,
  Camera,
  Umbrella,
  Compass
};

export const Maps: React.FC = () => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<Map | null>(null);
  const markerLayerRef = useRef<VectorLayer<VectorSource>>();
  const [error, setError] = useState<string>('');
  const [cityInfo, setCityInfo] = useState<string>('');
  const [recommendations, setRecommendations] = useState<PlaceInfo[]>([]);
  
  const { currentWeather, setCurrentWeather } = useContext(LocationContext);
  const { units } = useContext(SettingsContext);
  const { setBackgroundImage } = useContext(BackgroundContext);

  useEffect(() => {
    if (!mapRef.current) return;

    const map = new Map({
      target: mapRef.current,
      layers: [
        new TileLayer({
          source: new OSM(),
        }),
      ],
      view: new View({
        center: fromLonLat([0, 0]),
        zoom: 2,
      }),
    });

    const markerLayer = new VectorLayer({
      source: new VectorSource(),
    });
    map.addLayer(markerLayer);
    markerLayerRef.current = markerLayer;
    mapInstanceRef.current = map;

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.setTarget(undefined);
      }
    };
  }, []);

  useEffect(() => {
    if (currentWeather) {
      const { coord: { lat, lon }, name, sys: { country }, weather, main: { temp } } = currentWeather;
      
      // Update map view
      if (mapInstanceRef.current) {
        mapInstanceRef.current.getView().animate({
          center: fromLonLat([lon, lat]),
          zoom: 10,
          duration: 1000,
        });
        addMarker(lon, lat);
      }

      // Update city info and recommendations
      setCityInfo(`${name}, ${country} - ${weather[0].description}`);
      const locationRecs = getLocationRecommendations(
        weather[0].main,
        temp,
        name,
        country
      );
      setRecommendations(locationRecs.map(rec => ({
        ...rec,
        icon: iconMap[rec.icon] || Compass
      })));
    }
  }, [currentWeather]);

  const addMarker = (lon: number, lat: number) => {
    if (!markerLayerRef.current) return;

    const markerSource = markerLayerRef.current.getSource();
    if (!markerSource) return;

    markerSource.clear();

    const marker = new Feature({
      geometry: new Point(fromLonLat([lon, lat])),
    });

    const markerStyle = new Style({
      image: new Icon({
        anchor: [0.5, 1],
        src: 'https://openlayers.org/en/latest/examples/data/icon.png',
        scale: 0.5,
      }),
    });

    marker.setStyle(markerStyle);
    markerSource.addFeature(marker);
  };

  const handleSearch = async (city: string) => {
    try {
      const response = await fetch(
        `https://api.openweathermap.org/geo/1.0/direct?q=${city}&limit=1&appid=08d1d552fcc23843276535db21cdf95f`
      );
      const data = await response.json();

      if (data.length === 0) {
        setError('Location not found');
        return;
      }

      const { lat, lon, name, country } = data[0];
      
      const weatherResponse = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=${units}&appid=08d1d552fcc23843276535db21cdf95f`
      );
      
      const weatherData = await weatherResponse.json();
      setCurrentWeather(weatherData);

      const imageUrl = await fetchCityImage(city);
      if (imageUrl) {
        setBackgroundImage(imageUrl);
      }

      setError('');
    } catch (err) {
      setError('Error searching location');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4">
      <h1 className="text-3xl font-bold text-white text-center mb-4 md:mb-8">
        Weather Map & Travel Guide
      </h1>
      
      <div className="mb-6">
        <SearchBar onSearch={handleSearch} />
        {error && (
          <div className="mt-4 text-red-400 text-center">
            {error}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div 
            ref={mapRef} 
            className="w-full h-[400px] md:h-[600px] rounded-xl overflow-hidden shadow-lg"
          />
        </div>
        
        <div className="space-y-4">
          {cityInfo && (
            <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-xl font-semibold text-white mb-2">Location Info</h2>
              <p className="text-gray-300">{cityInfo}</p>
            </div>
          )}

          {recommendations.length > 0 && (
            <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-xl font-semibold text-white mb-4">Local Recommendations</h2>
              <div className="space-y-4">
                {recommendations.map((place, index) => {
                  const Icon = place.icon;
                  return (
                    <div key={index} className="bg-gray-700/30 p-4 rounded-lg transform hover:scale-105 transition-transform">
                      <div className="flex items-center gap-3 mb-2">
                        <Icon className="text-blue-400" size={20} />
                        <h3 className="text-white font-medium">{place.name}</h3>
                      </div>
                      <p className="text-gray-400 text-sm">{place.type}</p>
                      <p className="text-gray-300 mt-1">{place.description}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};