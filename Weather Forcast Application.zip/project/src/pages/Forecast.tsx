import React, { useState, useContext } from 'react';
import { SearchBar } from '../components/SearchBar';
import { fetchForecast, fetchCityImage } from '../utils/api';
import { Sun, Cloud, CloudRain, Wind, Droplets, Thermometer } from 'lucide-react';
import type { ForecastData } from '../types/weather';
import { BackgroundContext } from '../context/BackgroundContext';

export const Forecast: React.FC = () => {
  const [forecast, setForecast] = useState<ForecastData | null>(null);
  const [error, setError] = useState<string>('');
  const { setBackgroundImage } = useContext(BackgroundContext);

  const handleSearch = async (city: string) => {
    try {
      setError('');
      const [data, imageUrl] = await Promise.all([
        fetchForecast(city),
        fetchCityImage(city)
      ]);
      setForecast(data);
      if (imageUrl) {
        setBackgroundImage(imageUrl);
      }
    } catch (err) {
      setError('City not found. Please try again.');
    }
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'clear':
        return <Sun className="text-yellow-400" size={24} />;
      case 'clouds':
        return <Cloud className="text-gray-400" size={24} />;
      case 'rain':
        return <CloudRain className="text-blue-400" size={24} />;
      default:
        return <Sun className="text-yellow-400" size={24} />;
    }
  };

  const getDayName = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleDateString('en-US', { weekday: 'long' });
  };

  return (
    <div className="max-w-4xl mx-auto px-4">
      <h1 className="text-3xl font-bold text-white text-center mb-4">
        7-Day Weather Forecast
      </h1>

      <div className="text-center mb-8">
        <p className="text-gray-300">
          Get detailed weather predictions for the next 7 days, including temperature trends,
          precipitation chances, and atmospheric conditions. Plan your week with confidence
          using our accurate forecast data.
        </p>
      </div>

      <SearchBar onSearch={handleSearch} />

      {error && (
        <div className="mt-4 text-red-400 text-center">
          {error}
        </div>
      )}

      {forecast && (
        <div className="mt-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {forecast.list.slice(0, 21).map((item, index) => (
              <div key={index} className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white">
                      {getDayName(item.dt)}
                    </h3>
                    <p className="text-gray-400 text-sm">
                      {new Date(item.dt * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  {getWeatherIcon(item.weather[0].main)}
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Thermometer className="text-red-400" size={18} />
                      <span className="text-white">Temperature</span>
                    </div>
                    <span className="text-2xl font-bold text-white">
                      {Math.round(item.main.temp)}°C
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Thermometer className="text-orange-400" size={18} />
                      <span className="text-white">Feels Like</span>
                    </div>
                    <span className="text-white">
                      {Math.round(item.main.feels_like)}°C
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Wind className="text-blue-400" size={18} />
                      <span className="text-white">Wind Speed</span>
                    </div>
                    <span className="text-white">{item.wind.speed} m/s</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Droplets className="text-green-400" size={18} />
                      <span className="text-white">Humidity</span>
                    </div>
                    <span className="text-white">{item.main.humidity}%</span>
                  </div>

                  <div className="mt-4 pt-4 border-t border-gray-700">
                    <p className="text-gray-400 text-sm">
                      {item.weather[0].description.charAt(0).toUpperCase() + 
                       item.weather[0].description.slice(1)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-xl font-semibold text-white mb-4">Forecast Summary</h2>
            <p className="text-gray-300">
              This forecast provides detailed weather predictions for the next 7 days in 3-hour intervals.
              Use this information to plan your activities and stay prepared for any weather changes.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};