import React, { useState, useContext, useEffect } from 'react';
import { SearchBar } from '../components/SearchBar';
import { WeatherCard } from '../components/WeatherCard';
import { WeatherWidget, SunriseSunsetWidget } from '../components/WeatherWidget';
import { fetchWeather, fetchCityImage } from '../utils/api';
import type { WeatherData } from '../types/weather';
import { Users, Wind, Droplets, Eye, Gauge, CloudRain, Thermometer } from 'lucide-react';
import { BackgroundContext } from '../context/BackgroundContext';

export const Home: React.FC = () => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [error, setError] = useState<string>('');
  const [showTeam, setShowTeam] = useState(true);
  const { setBackgroundImage } = useContext(BackgroundContext);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      setShowTeam(currentScrollY <= lastScrollY || currentScrollY < 100);
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const handleSearch = async (city: string) => {
    try {
      setError('');
      const [weatherData, imageUrl] = await Promise.all([
        fetchWeather(city),
        fetchCityImage(city)
      ]);
      setWeather(weatherData);
      if (imageUrl) {
        setBackgroundImage(imageUrl);
      }
    } catch (err) {
      setError('City not found. Please try again.');
    }
  };

  const handleLocationClick = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            const response = await fetch(
              `https://api.openweathermap.org/data/2.5/weather?lat=${position.coords.latitude}&lon=${position.coords.longitude}&units=metric&appid=08d1d552fcc23843276535db21cdf95f`
            );
            const data = await response.json();
            setWeather(data);
            
            const cityImage = await fetchCityImage(data.name);
            if (cityImage) {
              setBackgroundImage(cityImage);
            }
            
            setError('');
          } catch (err) {
            setError('Error fetching weather data.');
          }
        },
        () => {
          setError('Error getting current location. Please enable location services.');
        }
      );
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 pb-24">
      <h1 className="text-3xl font-bold text-white text-center mb-4 md:mb-8">
        Welcome to Skycast
      </h1>
      
      <div className="text-center mb-8">
        <p className="text-gray-300 text-lg">
          Your comprehensive weather companion for accurate forecasts,
          air quality monitoring, and interactive weather maps.
          Get real-time updates and detailed insights about weather conditions worldwide.
        </p>
      </div>
      
      <SearchBar onSearch={handleSearch} onLocationClick={handleLocationClick} />
      
      {error && (
        <div className="mt-4 text-red-400 text-center">
          {error}
        </div>
      )}
      
      {weather && (
        <>
          <div className="mt-8">
            <WeatherCard weather={weather} />
          </div>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <WeatherWidget
              icon={Wind}
              title="Wind Speed"
              value={weather.wind.speed}
              unit="m/s"
              color="text-blue-400"
            />
            <WeatherWidget
              icon={Droplets}
              title="Humidity"
              value={weather.main.humidity}
              unit="%"
              color="text-green-400"
            />
            <WeatherWidget
              icon={Eye}
              title="Visibility"
              value={(weather.visibility / 1000).toFixed(1)}
              unit="km"
              color="text-purple-400"
            />
            <WeatherWidget
              icon={Gauge}
              title="Pressure"
              value={weather.main.pressure}
              unit="hPa"
              color="text-red-400"
            />
          </div>

          <div className="mt-8">
            <SunriseSunsetWidget
              sunrise={new Date(weather.sys.sunrise * 1000).toLocaleTimeString()}
              sunset={new Date(weather.sys.sunset * 1000).toLocaleTimeString()}
            />
          </div>

          <div className="mt-8 bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-xl font-semibold text-white mb-4">Weather Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-700/30 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <CloudRain className="text-blue-400" size={20} />
                  <h3 className="text-white font-medium">Precipitation</h3>
                </div>
                <p className="text-gray-300">{weather.weather[0].description}</p>
              </div>
              <div className="bg-gray-700/30 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Thermometer className="text-red-400" size={20} />
                  <h3 className="text-white font-medium">Temperature Range</h3>
                </div>
                <p className="text-gray-300">
                  Min: {Math.round(weather.main.temp_min)}°C / Max: {Math.round(weather.main.temp_max)}°C
                </p>
              </div>
            </div>
          </div>
        </>
      )}

      <div 
        className={`fixed bottom-0 left-0 right-0 bg-gray-800/50 backdrop-blur-sm p-4 transition-transform duration-300 ${
          showTeam ? 'translate-y-0' : 'translate-y-full'
        }`}
      >
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-4 mb-3">
            <Users className="text-blue-400" size={20} />
            <h2 className="text-lg font-semibold text-white">Meet Our Team</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-gray-700/30 p-3 rounded-lg">
              <h3 className="text-sm font-medium text-white">Lavin</h3>
              <p className="text-xs text-gray-400">Weather API Specialist</p>
            </div>
            <div className="bg-gray-700/30 p-3 rounded-lg">
              <h3 className="text-sm font-medium text-white">Vasu Rawat</h3>
              <p className="text-xs text-gray-400">UI Designer</p>
            </div>
            <div className="bg-gray-700/30 p-3 rounded-lg">
              <h3 className="text-sm font-medium text-white">Ayush Rathore</h3>
              <p className="text-xs text-gray-400">Front-end Developer</p>
            </div>
            <div className="bg-gray-700/30 p-3 rounded-lg">
              <h3 className="text-sm font-medium text-white">Akshun Jolly</h3>
              <p className="text-xs text-gray-400">Data Visualization</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};