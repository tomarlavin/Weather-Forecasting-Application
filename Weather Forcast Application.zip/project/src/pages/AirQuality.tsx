import React, { useState } from 'react';
import { SearchBar } from '../components/SearchBar';
import { Wind, Droplets, Sun, AlertTriangle, Leaf, Gauge, ThermometerSun, Activity } from 'lucide-react';

export const AirQuality: React.FC = () => {
  const [airQuality, setAirQuality] = useState<any>(null);
  const [error, setError] = useState<string>('');

  const handleSearch = async (city: string) => {
    try {
      const geoResponse = await fetch(
        `https://api.openweathermap.org/geo/1.0/direct?q=${city}&limit=1&appid=08d1d552fcc23843276535db21cdf95f`
      );
      const geoData = await geoResponse.json();

      if (geoData.length === 0) {
        throw new Error('City not found');
      }

      const { lat, lon } = geoData[0];

      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=08d1d552fcc23843276535db21cdf95f`
      );
      const data = await response.json();
      setAirQuality(data);
      setError('');
    } catch (err) {
      setError('Unable to fetch air quality data.');
    }
  };

  const handleLocationClick = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        try {
          const response = await fetch(
            `https://api.openweathermap.org/data/2.5/air_pollution?lat=${position.coords.latitude}&lon=${position.coords.longitude}&appid=08d1d552fcc23843276535db21cdf95f`
          );
          const data = await response.json();
          setAirQuality(data);
          setError('');
        } catch (err) {
          setError('Error fetching air quality data.');
        }
      });
    }
  };

  const getAirQualityLevel = (aqi: number) => {
    const levels = ['Good', 'Fair', 'Moderate', 'Poor', 'Very Poor'];
    return levels[aqi - 1] || 'Unknown';
  };

  const getHealthImplications = (aqi: number) => {
    const implications = [
      'Air quality is satisfactory, poses little or no risk.',
      'Acceptable air quality but some pollutants may be moderate.',
      'Members of sensitive groups may experience health effects.',
      'Everyone may begin to experience health effects.',
      'Health alert: everyone may experience serious health effects.'
    ];
    return implications[aqi - 1] || 'Unknown health implications';
  };

  return (
    <div className="max-w-4xl mx-auto px-4">
      <h1 className="text-3xl font-bold text-white text-center mb-4">
        Air Quality Index
      </h1>

      <div className="text-center mb-8">
        <p className="text-gray-300">
          Monitor real-time air quality data and understand its impact on your health.
          Our comprehensive air quality metrics help you make informed decisions about outdoor activities.
        </p>
      </div>

      <SearchBar onSearch={handleSearch} onLocationClick={handleLocationClick} />

      {error && (
        <div className="mt-4 text-red-400 text-center">
          {error}
        </div>
      )}

      {airQuality && (
        <div className="mt-8 space-y-6">
          <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
            <div className="flex items-center space-x-4 mb-4">
              <Activity className="text-blue-400" size={24} />
              <h2 className="text-xl font-semibold text-white">Air Quality Status</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-700/30 p-4 rounded-lg">
                <p className="text-gray-400 text-sm">AQI Level</p>
                <p className="text-white font-semibold text-lg">
                  {getAirQualityLevel(airQuality.list[0].main.aqi)}
                </p>
                <p className="text-sm text-gray-400 mt-2">
                  {getHealthImplications(airQuality.list[0].main.aqi)}
                </p>
              </div>
              <div className="bg-gray-700/30 p-4 rounded-lg">
                <p className="text-gray-400 text-sm">Health Advisory</p>
                <div className="flex items-center gap-2 mt-2">
                  <AlertTriangle className="text-yellow-400" size={20} />
                  <p className="text-white">
                    {airQuality.list[0].main.aqi > 2 ? 'Consider reducing outdoor activities' : 'Safe for outdoor activities'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
              <div className="flex items-center space-x-4 mb-4">
                <Leaf className="text-green-400" size={24} />
                <h2 className="text-xl font-semibold text-white">Primary Pollutants</h2>
              </div>
              <div className="space-y-4">
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <p className="text-gray-400 text-sm">PM2.5 (Fine particles)</p>
                  <p className="text-white font-semibold">
                    {airQuality.list[0].components.pm2_5.toFixed(1)} µg/m³
                  </p>
                </div>
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <p className="text-gray-400 text-sm">PM10 (Coarse particles)</p>
                  <p className="text-white font-semibold">
                    {airQuality.list[0].components.pm10.toFixed(1)} µg/m³
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm">
              <div className="flex items-center space-x-4 mb-4">
                <ThermometerSun className="text-orange-400" size={24} />
                <h2 className="text-xl font-semibold text-white">Other Pollutants</h2>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <p className="text-gray-400 text-sm">NO2</p>
                  <p className="text-white font-semibold">
                    {airQuality.list[0].components.no2.toFixed(1)} µg/m³
                  </p>
                </div>
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <p className="text-gray-400 text-sm">SO2</p>
                  <p className="text-white font-semibold">
                    {airQuality.list[0].components.so2.toFixed(1)} µg/m³
                  </p>
                </div>
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <p className="text-gray-400 text-sm">O3</p>
                  <p className="text-white font-semibold">
                    {airQuality.list[0].components.o3.toFixed(1)} µg/m³
                  </p>
                </div>
                <div className="bg-gray-700/30 p-4 rounded-lg">
                  <p className="text-gray-400 text-sm">CO</p>
                  <p className="text-white font-semibold">
                    {airQuality.list[0].components.co.toFixed(1)} µg/m³
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};